class Main {
  public static void main(String[] args) {
    //System.out.println("Hello world!");
    list ll=new list();
    ll.atstart(5);
    ll.atend(10);
    ll.atend(12);
    ll.atstart(182);
    ll.atend(25);
    ll.atstart(979);
    ll.show();
  }
}